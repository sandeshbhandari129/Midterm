import React, { useState } from 'react';

function UpdateLogoButton() {
  const [logoIndex, setLogoIndex] = useState(0);

  const logoURLs = [
    '/public/logo1.png', 
    '/public/logo2.png',
    '/public/logo3.png',
  ];

  const handleUpdateLogo = () => {
    setLogoIndex((prevIndex) => (prevIndex + 1) % logoURLs.length);
  };

  return (
    <div>
      <img src={logoURLs[logoIndex]} alt="Logo" style={{ width: '100px', height: '100px' }} />
      <button onClick={handleUpdateLogo}>Update Logo</button>
    </div>
  );
}

export default UpdateLogoButton;
