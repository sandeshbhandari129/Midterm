import React, { useState } from 'react';
import UpdateLogoButton from './logo';
import NameDescriptionFields from './fields';


function ShopForm() {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData);
    setFormData({ name: '', description: '' }); // Reset the form data
  };

  const handleCancel = () => {
    setFormData({ name: '', description: '' });
  };

  return (
    <div className="shop-form-container">
      <form onSubmit={handleSubmit}>
        <div className="center-content">
          <UpdateLogoButton />
        </div>
        <div className="center-content">
          <NameDescriptionFields formData={formData} setFormData={setFormData} />
        </div>
        <div className="center-content">
          <button type="submit" className="submit-button">
            Submit
          </button>
        </div>
        <div className="center-content">
          <button type="button" onClick={handleCancel} className="cancel-button">
            Cancel
          </button>
        </div>
      </form>
    </div>
  );
}

export default ShopForm;
