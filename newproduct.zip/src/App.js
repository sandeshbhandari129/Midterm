
import React from 'react';
import ShopForm from './components/shopform';

function App() {
  return (
    <div><div className="App">
      <h1>New Shop</h1>
      <ShopForm />
    </div></div>
  );
}

export default App;
