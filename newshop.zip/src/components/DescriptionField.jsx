import React from 'react';

function DescriptionField({ formData, setFormData }) {
  const handleDescriptionChange = (e) => {
    setFormData({ ...formData, description: e.target.value });
  }

  return (
    <div>
      <label>Description:</label>
      <input
        type="text"
        value={formData.description}
        onChange={handleDescriptionChange}
        placeholder="Product Description"
      />
    </div>
  );
}

export default DescriptionField;
