import React from 'react';

function PriceField({ formData, setFormData }) {
  const handlePriceChange = (e) => {
    setFormData({ ...formData, price: e.target.value });
  }

  return (
    <div>
      <label>Price:</label>
      <input
        type="number"
        value={formData.price}
        onChange={handlePriceChange}
        placeholder="Product Price"
      />
    </div>
  );
}

export default PriceField;
