import React from 'react';

function NameField({ formData, setFormData }) {
  const handleNameChange = (e) => {
    setFormData({ ...formData, name: e.target.value });
  }

  return (
    <div>
      <label>Name:</label>
      <input
        type="text"
        value={formData.name}
        onChange={handleNameChange}
        placeholder="Product Name"
      />
    </div>
  );
}

export default NameField;
