import React from 'react';

function CategoryField({ formData, setFormData }) {
  const handleCategoryChange = (e) => {
    setFormData({ ...formData, category: e.target.value });
  }

  return (
    <div>
      <label>Category:</label>
      <input
        type="text"
        value={formData.category}
        onChange={handleCategoryChange}
        placeholder="Product Category"
      />
    </div>
  );
}

export default CategoryField;
