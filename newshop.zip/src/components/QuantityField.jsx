import React from 'react';

function QuantityField({ formData, setFormData }) {
  const handleQuantityChange = (e) => {
    setFormData({ ...formData, quantity: e.target.value });
  }

  return (
    <div>
      <label>Quantity:</label>
      <input
        type="number"
        value={formData.quantity}
        onChange={handleQuantityChange}
        placeholder="Product Quantity"
      />
    </div>
  );
}

export default QuantityField;
