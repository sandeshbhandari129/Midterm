import React, { useState } from 'react';
import NameField from './NameField'; 
import DescriptionField from './DescriptionField'; 
import CategoryField from './CategoryField'; 
import QuantityField from './QuantityField'; 
import PriceField from './PriceField'; 

function ProductForm() {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: '',
    quantity: '',
    price: '',
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    
    console.log(formData);
  }

  const handleCancel = () => {
    setFormData({
      name: '',
      description: '',
      category: '',
      quantity: '',
      price: '',
    });
  }

  return (
    <div>
      <header title="New Product" />

      <form onSubmit={handleSubmit}>
        <NameField formData={formData} setFormData={setFormData} />
        <DescriptionField formData={formData} setFormData={setFormData} /> 
        <CategoryField formData={formData} setFormData={setFormData} /> 
        <QuantityField formData={formData} setFormData={setFormData} /> 
        <PriceField formData={formData} setFormData={setFormData} /> 
        <div>
          <button type="submit">Submit</button>
          <button type="button" onClick={handleCancel}>Cancel</button>
        </div>
      </form>
    </div>
  );
}

export default ProductForm;
